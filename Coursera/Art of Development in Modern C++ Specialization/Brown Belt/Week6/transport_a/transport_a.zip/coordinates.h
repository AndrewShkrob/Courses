#ifndef BROWN_BELT_COORDINATES_H
#define BROWN_BELT_COORDINATES_H

struct Coords {
    double latitude = 0;
    double longitude = 0;
};

#endif //BROWN_BELT_COORDINATES_H
